package com.example.homework8;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private final int ADD_CONTACT_REQUEST = 1;
    private ArrayList<Contact> contacts = new ArrayList<>();
    private ArrayAdapter<Contact> adapter;
    private ContactDatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new ContactDatabaseHelper(this);

        ListView contactListView = findViewById(R.id.contactListView);
        Button addContactButton = findViewById(R.id.addContactButton);

        // Initialize the adapter and set it to the ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contacts);
        contactListView.setAdapter(adapter);

        // Add the data from the database to the contacts list
        contacts.addAll(db.getAllContacts());
        // Notify the adapter that the data has changed
        adapter.notifyDataSetChanged();

        addContactButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddContactActivity.class);
            startActivityForResult(intent, ADD_CONTACT_REQUEST);
        });

        contactListView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(MainActivity.this, ContactDetailsActivity.class);
            Contact selectedContact = contacts.get(position);
            intent.putExtra("name", selectedContact.getName());
            intent.putExtra("phone", selectedContact.getPhoneNumber());
            intent.putExtra("email", selectedContact.getEmail());
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_CONTACT_REQUEST && resultCode == RESULT_OK) {
            String name = data.getStringExtra("name");
            String phone = data.getStringExtra("phone");
            String email = data.getStringExtra("email");
            Contact newContact = new Contact(name, phone, email);
            db.addContact(newContact); // Save the new contact to the database
            contacts.add(newContact);
            adapter.notifyDataSetChanged();
        }
    }
}
