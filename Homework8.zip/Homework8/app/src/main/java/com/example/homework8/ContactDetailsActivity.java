package com.example.homework8;

import android.os.Bundle;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class ContactDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact_details);

        TextView nameDetailTextView = findViewById(R.id.nameDetailTextView);
        TextView phoneDetailTextView = findViewById(R.id.phoneDetailTextView);
        TextView emailDetailTextView = findViewById(R.id.emailDetailTextView);

        Intent intent = getIntent();
        nameDetailTextView.setText(intent.getStringExtra("name"));
        phoneDetailTextView.setText(intent.getStringExtra("phone"));
        emailDetailTextView.setText(intent.getStringExtra("email"));
    }
}