package com.example.homework8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class ContactDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "contacts.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "contacts";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_PHONE = "phone";
    private static final String COLUMN_EMAIL = "email";

    public ContactDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_PHONE + " TEXT, " +
                COLUMN_EMAIL + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, contact.getName());
        values.put(COLUMN_PHONE, contact.getPhoneNumber());
        values.put(COLUMN_EMAIL, contact.getEmail());

        try {
            db.insert(TABLE_NAME, null, values);
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception as needed
        } finally {
            db.close();
        }
    }

    public ArrayList<Contact> getAllContacts() {
        ArrayList<Contact> contacts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            String selectAllQuery = "SELECT * FROM " + TABLE_NAME;
            cursor = db.rawQuery(selectAllQuery, null);

            if (cursor != null) {
                int columnIndexId = cursor.getColumnIndex(COLUMN_ID);
                int columnIndexName = cursor.getColumnIndex(COLUMN_NAME);
                int columnIndexPhone = cursor.getColumnIndex(COLUMN_PHONE);
                int columnIndexEmail = cursor.getColumnIndex(COLUMN_EMAIL);

                if (columnIndexId != -1 && columnIndexName != -1 && columnIndexPhone != -1 && columnIndexEmail != -1) {
                    while (cursor.moveToNext()) {
                        int id = cursor.getInt(columnIndexId);
                        String name = cursor.getString(columnIndexName);
                        String phone = cursor.getString(columnIndexPhone);
                        String email = cursor.getString(columnIndexEmail);
                        contacts.add(new Contact( name, phone, email));
                    }
                }
                cursor.close();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception as needed
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return contacts;
    }
}
